from django.shortcuts import render,HttpResponse
from googleapiclient.discovery import build
import json
from oauth2client import file, client, tools
# Create your views here.
from django.shortcuts import render,HttpResponse
from googleapiclient.discovery import build
import json
from oauth2client import file, client, tools
# Create your views here.
from httplib2 import Http
import gspread
from oauth2client.service_account import ServiceAccountCredentials
scope = ['https://spreadsheets.google.com/feeds',
         'https://www.googleapis.com/auth/drive']
credentials = ServiceAccountCredentials.from_json_keyfile_name('/home/box/Desktop/MyPy/shit-happening/ReportMaker/Test-7b006314ebd8.json', scope)
sheets = build('sheets', 'v4', http=credentials.authorize(Http()))
gs = gspread.authorize(credentials)

def index(request):
    all_sheets = gs.list_spreadsheet_files()
    names = []
    for i in all_sheets:
        names.append(i["name"])
    return render(request,"index.html",{"names":names})
def submit(request):
    invoice = request.POST.get("invoice")
    type = request.POST.get("type")
    name = (request.POST.get("name"))
    date = (request.POST.get("date"))
    chasis = (request.POST.get("chasis"))
    address = (request.POST.get("address"))
    engine = (request.POST.get("engine"))
    reg = (request.POST.get("registration"))
    psd = request.POST.get("psd")
    ped = request.POST.get("ped")
    noe = request.POST.get("name_exec")
    nce = request.POST.get("contact_exec")
    ic = request.POST.get("insurace_comp")
    policyno = request.POST.get("policy_no")
    email = request.POST.get("email")
    lncb = request.POST.get("lncb")
    hypothecation = request.POST.get("hypo")
    make = request.POST.get("make")
    model = request.POST.get("model")
    gvw = request.POST.get("gvw")
    yom = request.POST.get("yom")
    scheme = request.POST.get("scheme")
    variant= request.POST.get("variant")
    private = request.POST.get("private")
    policy = request.POST.get("normal")
    at = request.POST.get("tow")
    premium = request.POST.get("premium")
    pod = request.POST.get("odpremium")
    disc = request.POST.get("discount")
    acl = request.POST.get("acl")
    esprice = request.POST.get("esp")
    idv = request.POST.get("idv")
    imt = request.POST.get("imt")
    payment = request.POST.get("pt")
    cheque = request.POST.get("ct")
    bank = request.POST.get("bank")
    chequeno = request.POST.get("cheque")
    values = [[invoice,type,name,date,chasis,address,engine,reg,psd,ped,noe,nce,ic,policyno,email,lncb,hypothecation,make,model,gvw,yom,scheme,variant,private,policy,at,premium,pod,disc,acl,esprice,idv,imt,payment,cheque,bank,chequeno]]
    data = {
        "values":values
    }
    print(data)
    sheet_name = request.session['current_edit']
    print(request.session['current_edit'])
    sheet_obj = gs.open(sheet_name)
    sheet_id = sheet_obj.id
    sheets.spreadsheets().values().append(spreadsheetId=sheet_id,body = data,range="sheet1",valueInputOption='USER_ENTERED').execute()
    content = True
    return HttpResponse(json.dumps(content), content_type='application/json')
def create_new_sheet(request):

    print('entered')
    sheet_name = request.GET.get("new_sheet")
    email = request.GET.get("email")
    spreadsheet = {
    'properties': {
        'title': sheet_name
    }
    }
    values = [

        ['SR',	'INSURANCE DATE',	'ENGINE NO.','CHASSIS NO',	'NAME OF CUSTOMER',	'VEHICLE NO.',	'NAME OF EXECUTIVE',	'CONTACT NO.',	'EMAIL ID'	,				'POLICY NO.'	,'INVOICE NO',	'CHEQUE NO',	'EXECUTIVE/BRANCH',	'START DATE',	'END DATE',	'NEW/RENEWAL/ROLL OVER',	'INSURANCE COMPANY',	'INVOICE DATE'	,'HYPOCATHICATION',	'MAKE',	'YEAR OF MANUFATURE',	'UNDER SCHEME'	,'COVER NOTE NO.',	'LOB'	,'MODEL',	'EX SHOWROOM PRICEW',	'IDV',	'PREMIUM'	,'IMT23'	,'OD'	,'DISCOUNT',	'CHEQUE BY',	'DISPATCH DATE',	'ADDRESS'	]
    ]
    data = {'values':values}

    sheet = sheets.spreadsheets().create(body=spreadsheet,fields='spreadsheetId').execute()
    sheet_id = sheet['spreadsheetId']
    sheets.spreadsheets().values().update(spreadsheetId=sheet_id,body = data,range="sheet1",valueInputOption="USER_ENTERED").execute()
    gs_sheet = gs.open_by_key(sheet_id)
    gs_sheet.share(email,perm_type="user",role="writer")
    content = True
    return HttpResponse(json.dumps(content), content_type='application/json')

def current_edit(request):

    content = request.session["current_edit"] = request.GET.get("current_edit")
    print('selected')
    print(request.session["current_edit"])

    return HttpResponse(json.dumps(content), content_type='application/json')

