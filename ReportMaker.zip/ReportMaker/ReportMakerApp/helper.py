from django.shortcuts import render,HttpResponse
from googleapiclient.discovery import build
import json
from oauth2client import file, client, tools
# Create your views here.
from httplib2 import Http
import gspread
from oauth2client.service_account import ServiceAccountCredentials
scope = ['https://spreadsheets.google.com/feeds',
         'https://www.googleapis.com/auth/drive']
credentials = ServiceAccountCredentials.from_json_keyfile_name('/home/box/Desktop/MyPy/shit-happening/ReportMaker/Test-7b006314ebd8.json', scope)
sheets = build('sheets', 'v4', http=credentials.authorize(Http()))
gs = gspread.authorize(credentials)
sheet = gs.list_spreadsheet_files()

for i in sheet:
    print(i)
