from django.apps import AppConfig


class ReportmakerappConfig(AppConfig):
    name = 'ReportMakerApp'
